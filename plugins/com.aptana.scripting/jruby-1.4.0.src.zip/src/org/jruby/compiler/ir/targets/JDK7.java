package org.jruby.compiler.ir.targets;

// This class represents JDK7 as the compiler target
// JDK7 supports invokedynamic for example
public class JDK7 extends JVM
{
}
