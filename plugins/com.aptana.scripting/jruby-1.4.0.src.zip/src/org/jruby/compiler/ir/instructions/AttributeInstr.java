package org.jruby.compiler.ir.instructions;

import org.jruby.compiler.ir.Operation;

public class AttributeInstr extends NoOperandInstr
{
    public AttributeInstr(Operation op) { super(op); }
}
