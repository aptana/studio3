package org.jruby.compiler.ir.operands;

public class GlobalVariable extends Variable
{
    public GlobalVariable(String n) { super(n); }
}
