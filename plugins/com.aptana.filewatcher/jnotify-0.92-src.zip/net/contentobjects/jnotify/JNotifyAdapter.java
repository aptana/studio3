package net.contentobjects.jnotify;

public class JNotifyAdapter implements JNotifyListener
{
	public void fileCreated(int wd, String rootPath, String name)
	{
	}

	public void fileDeleted(int wd, String rootPath, String name)
	{
	}

	public void fileModified(int wd, String rootPath, String name)
	{
	}

	public void fileRenamed(int wd, String rootPath, String oldName, String newName)
	{
	}
}
