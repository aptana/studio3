/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jruby.compiler;

/**
 *
 * @author enebo
 */
public class TwoBranchCallback {
    public void valid() {
    }

    public void invalid() {
    }
}
