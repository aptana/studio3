package org.jruby.compiler.ir.operands;

public class GlobalVariable extends LocalVariable {
    public GlobalVariable(String n) { 
        super(n);
    }
}
