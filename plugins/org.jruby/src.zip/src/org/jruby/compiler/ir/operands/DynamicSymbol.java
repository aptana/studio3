package org.jruby.compiler.ir.operands;

public class DynamicSymbol extends DynamicReference
{
    public DynamicSymbol(CompoundString s) { super(s); }
}
