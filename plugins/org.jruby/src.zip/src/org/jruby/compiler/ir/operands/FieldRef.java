package org.jruby.compiler.ir.operands;

public class FieldRef extends Reference
{
    public FieldRef(String n) { super(n); }
}
