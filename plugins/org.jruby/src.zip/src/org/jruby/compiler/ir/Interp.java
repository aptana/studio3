package org.jruby.compiler.ir;

/**
 * Marker Enumeration for indicating which methods in the IR are for runtime
 * use versus compiler use.
 */
public @interface Interp {
}
