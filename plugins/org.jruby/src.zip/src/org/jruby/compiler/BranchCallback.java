/*
 * BranchCallback.java
 *
 * Created on January 3, 2007, 4:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.jruby.compiler;

/**
 *
 * @author headius
 */
public interface BranchCallback {
    public void branch(BodyCompiler context);
}
