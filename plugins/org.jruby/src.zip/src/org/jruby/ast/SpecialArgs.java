package org.jruby.ast;

/**
 * Marker for special arguments (see {F,}CallSpecialArgsNode...
 */
public interface SpecialArgs {
    
}
